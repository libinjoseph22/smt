<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <th width="20%"> <?php echo $this->lang->line('title'); ?></th>
            <td><?php echo $faq->title; ?></td>
        </tr>

        <tr>
            <th><?php echo $this->lang->line('description'); ?></th>
            <td><?php echo $faq->description; ?></td>
        </tr>
         
    </tbody>
</table>
